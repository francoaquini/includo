<?php
require __DIR__ . '/includo.php';
